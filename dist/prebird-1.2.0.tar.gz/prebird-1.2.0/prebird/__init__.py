#Prebird
#Coded by L. Adrián Hernández A.

from prebird.prebird import spec, process, display, result