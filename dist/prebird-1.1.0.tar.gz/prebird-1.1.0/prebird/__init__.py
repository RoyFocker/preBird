#Prebird
#Coded by L. Adrián Hernández A.

from prebird.scyspec import test